
window.onscroll = function() {myFunction()};

function myFunction() {
    if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
        document.getElementById("onscroll-head").className = "header onscroll";
    } else {
        document.getElementById("onscroll-head").className = "header";
    }
}

(function($) {

	$("#contact-form").submit(function(e) {

		//prevent form from submiting the native way
		e.preventDefault();

		var form = $('#contact-form');
		var formData = $(form).serialize();
		
		//ajax post for form
		$.ajax({
	        url: "/myportfolio/index.html",
	        type: "post",
	        data: formData,
	        success: function(data, status) {
	            //console.log(data);
	        }
	    }).done(function(response) {
	        $('#form-response').html('<div class="callout success">' + response + '</div>');

	        //reset form
	        $("#contact-form")[0].reset();
	    }).fail(function(data) {
	    	$('#form-response').html('<div class="callout error">' + data + '</div>');
	    });
	});

	$('a.arrow-down').on('click', function(){
		var target = $(this).attr('href');
		target = $(target).offset().top - 56;
		TweenMax.to($(window), 1, {scrollTo:{y:target, autoKill: true}, ease:Power3.easeOut});
		return false;
	});

	$('.menu ul li a').on('click', function(){
		var target = $(this).attr('href');
		target = $(target).offset().top - 56;
		TweenMax.to($(window), 1, {scrollTo:{y:target, autoKill: true}, ease:Power3.easeOut});
		return false;
	});
	
	//Head & menu scroll animation
	var head = $('.header'),
		//headContact = $('.head-contact'),
		//socialMedia = $('.social-media'),
		//socialMediaLinks = $('.social-media a'),
		menu = $('.menu'),
		logo = $('.logo'),
		menuLinks = $('.menu li'),
		tlHead = new TimelineMax({});

	var head_tween = tlHead
			.fromTo(head, 0.3, {y: -10, autoAlpha: 1}, {y: 0, autoAlpha: 1, ease:Power1.easeOut}).add('intro')
			//.fromTo(headContact, 0.3, {x: -10, autoAlpha: 0}, {x: 0, autoAlpha: 1, ease:Power1.easeOut}, '-=0.15')
			//.fromTo(socialMedia, 0.3, {x: -10, autoAlpha: 0}, {x: 0, autoAlpha: 1, ease:Power1.easeOut}, '-=0.15')
			// .staggerFrom(socialMediaLinks, 1, {cycle: {
			// 	x: 2, y: 2,
			// }, autoAlpha: 0, ease:Quad.easeInOut}, 0.2)
			.fromTo(menu, 0.3, {x: -10, autoAlpha: 0}, {x: 0, autoAlpha: 1, ease:Power1.easeOut}, 'intro')
			.fromTo(logo, 0.3, {autoAlpha: 0, scale: 1.3}, {autoAlpha: 1, scale: 1, ease:Power0.easeNone}, 'intro')
			.staggerFrom(menuLinks, 0.5, {cycle: {
				x: [15],
			}, autoAlpha: 0, ease:Power1.easeOut}, 0.2, 'intro');

	//banner scroll animation
	var banner = $('.banner'),
		bannerArrowDown = $('a.arrow-down'),
		bannerCaption = $('.caption'),
		tlBanner = new TimelineMax({});

	var banner_tween = tlBanner
			.fromTo(banner, 0.3, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.15')
			.fromTo(bannerCaption, 0.5, {y: 0, autoAlpha: 0}, {y: -100, autoAlpha: 1, ease:Power2.easeOut}, '+=0.25')
			.fromTo(bannerArrowDown, 0.3, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.15');
		
	//Home page animation
	var mainContent = $('#works'),
		links = $('#works ul li.work'),
		tlMainContent = new TimelineMax({});

	var h_about_tween = tlMainContent
		.fromTo(mainContent, 0.3, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.2')
		.staggerFrom(links, 1, {cycle: {
		 			y: [-35],
		 		}, autoAlpha: 0, ease:Power1.easeOut}, 0.2);
			
	//Home page Works animation
	var works = $('#works'),
		worksLinks = $('#works ul li.work'),
		tlWorks = new TimelineMax({opacity: 0, immediateRender: false});

	var h_work_tween = tlWorks
		.fromTo(works, 0, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.25').add('intro')
		.staggerFrom(worksLinks, 0.5, {cycle: {
	 			x: [200],
	 		}, autoAlpha: 0, ease:Power1.easeOut}, 0.2, 'intro');

	var aboutMe = $('#about-me'),
		largeText = $('span.large-text'),
		skills = $('ul.skills li'),
		tlAboutMe = new TimelineMax({opacity: 0, immediateRender: false});

	var h_aboutme_tween = tlAboutMe
		.fromTo(aboutMe, 0, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.25').add('intro')
		.fromTo(largeText, 0.5, {x: -10, autoAlpha: 0}, {x: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.45').add('second-intro')
		.staggerFrom(skills, 1, {cycle: {
		 			y: [-35],
		 		}, autoAlpha: 0, ease:Power1.easeOut}, 0.2, 'second-intro');

	var contactMe = $('#contact-me'),
		contactForm = $('.contact-form'),
		tlContactMe = new TimelineMax({opacity: 0, immediateRender: false});

	var h_contactme_tween = tlContactMe
		.fromTo(contactMe, 0, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.25').add('intro')
		.fromTo(contactForm, 0.5, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, 'intro+=0.45');

	//footer animation
	var footer = $('.footer'),
		tlfooter = new TimelineMax({});

	var footer_tween = tlfooter
		.fromTo(footer, 0.3, {y: -10, autoAlpha: 0}, {y: 0, autoAlpha: 1, ease:Power2.easeOut}, '+=0.25');
				
	// init ScrollMagic Controller
	var controller = new ScrollMagic.Controller({
		globalSceneOptions: {
			triggerElement: '.section',
 			triggerHook: 'onEnter',
			addIndicators: true,
			reverse: false
		}
	});

	//$("div.section").each(function() {
		// Scale Scene
		var head_scene = new ScrollMagic.Scene({
			offset: 100,
			//reverse:false
		})
		.addTo(controller)
		.triggerHook("onEnter")
		.triggerElement(head[0])
		.setTween(head_tween);

		var banner_scene = new ScrollMagic.Scene({
		  offset: 100,
		})
		.addTo(controller)
		.triggerHook("onEnter")
		.triggerElement(banner[0])
		.setTween(banner_tween);

		var h_main_content_scene = new ScrollMagic.Scene({
		  	offset: 100,
		  	//reverse:false
		})
		.addTo(controller)
		.triggerHook("onEnter")
		.triggerElement(mainContent[0])
		.setTween(h_about_tween);

		var h_work_scene = new ScrollMagic.Scene({
		  	offset: 100,
		  	//reverse:false
		})
		.addTo(controller)
		.triggerHook("onEnter")
		.triggerElement(works[0])
		.setTween(h_work_tween);

		var h_about_scene = new ScrollMagic.Scene({
		  	offset: 100,
		  	//reverse:false
		})
		.addTo(controller)
		.triggerHook("onEnter")
		.triggerElement(aboutMe[0])
		.setTween(h_aboutme_tween);

		var h_contactme_scene = new ScrollMagic.Scene({
		  	offset: 400,
		  	//reverse:false
		})
		.addTo(controller)
		.triggerHook("onEnter")
		.triggerElement(contactMe[0])
		.setTween(h_contactme_tween);
	//});

	// $(window).scroll( function(){
	//   var st = $(this).scrollTop();
	//   var ht = $( 'div.section' ).height();
	//    if( st < ht && st > 0 ){
	//         windowScroll = st/ht;
	//         tlWorks.progress(windowScroll);
	//     }
	// });

	// cache the navigation links 
	var lastId,
	 topMenu = $('.menu ul'),
	 topMenuHeight = topMenu.outerHeight()+1,
	 // All list items
	 menuItems = topMenu.find("a"),
	 // Anchors corresponding to menu items
	 scrollItems = menuItems.map(function(){
	   var item = $($(this).attr("href"));
	    if (item.length) { return item; }
	 });


	// Bind to scroll
	$(window).scroll(function(){
	   // Get container scroll position
	   var fromTop = $(this).scrollTop()+topMenuHeight;
	   
	   // Get id of current scroll item
	   var cur = scrollItems.map(function(){
	     if ($(this).offset().top < fromTop + 20)
	       return this;
	   });
	   // Get the id of the current element
	   cur = cur[cur.length-1];
	   var id = cur && cur.length ? cur[0].id : "";
	   
	   if (lastId !== id) {
	       lastId = id;
	       // Set/remove active class
	       menuItems
	         .parent().removeClass("active")
	         .end().filter("[href=\\#"+id+"]").parent().addClass("active");
	   }                   
	});
}(jQuery));