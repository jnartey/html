//Importing Express
const express = require('express');
var bodyParser = require("body-parser");
const app = express();

//Importing node mailer
var nodemailer = require('nodemailer');

//Configuring express to use body-parser as middle-ware
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());

//Listening for get [get request](URL)
app.use(express.static('htdocs'));
app.get('/', (request, response) => response.send('Hello World, Server Works!'));//Lambda expression

//Getting post
// app.post('/', (request, response) => {
//
// })

app.post('/form/register.html', handlePostResquest);
app.post('/myportfolio/index.html', handlePostResquestEmail);

app.listen(3000, () => console.log('Server is ready...listening on port 3000!'));

function handlePostResquest(request, response) {
	console.log(request.body);
	response.send('OK');
}

var username = "jnartey@gmail.com", password = "Ephesians117";
var senderemail, sendername, sendermessage;

function handlePostResquestEmail(request, response) {
	senderemail = request.body.email;
	sendername = request.body.fullname;
	sendermessage = request.body.message;

	console.log(request.body);

	//Email transporter
	var transporter = nodemailer.createTransport({
	  service: 'gmail',
	  auth: {
	    user: username,
	    pass: password
	  }
	});

	var mailOptions = {
	  from: senderemail,
	  to: username,
	  subject: 'Email from ' + sendername,
	  text: sendermessage
	};

	transporter.sendMail(mailOptions, function(error, info){
	  if (error) {
	    console.log(error);
	    response.send("Error sending mail");
	  } else {
	    console.log('Email sent: ' + info.response);
	    response.send("Email succesfully sent... thank you for contacting me, i will get back to you as soon as i see your message.");
	  }
	});

	transporter.close();	
}

